
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import org.openqa.selenium.WebDriver

import java.lang.String

import org.apache.poi.hssf.usermodel.HSSFCell

import com.kms.katalon.core.testobject.TestObject


def static "pac.runteststeps.steps"(
    	WebDriver driver	
     , 	String action	
     , 	String value	
     , 	String attribute	
     , 	String attrval	) {
    (new pac.runteststeps()).steps(
        	driver
         , 	action
         , 	value
         , 	attribute
         , 	attrval)
}

def static "utils.ExcelUtils.setExcelFile"(
    	String path	) {
    (new utils.ExcelUtils()).setExcelFile(
        	path)
}

def static "utils.ExcelUtils.setExcelsheet"(
    	String Sheetname	) {
    (new utils.ExcelUtils()).setExcelsheet(
        	Sheetname)
}

def static "utils.ExcelUtils.getRowCount"(
    	String SheetName	) {
    (new utils.ExcelUtils()).getRowCount(
        	SheetName)
}

def static "utils.ExcelUtils.getCellData"(
    	int rowNum	
     , 	int ColNum	) {
    (new utils.ExcelUtils()).getCellData(
        	rowNum
         , 	ColNum)
}

def static "utils.ExcelUtils.CellToString"(
    	HSSFCell cell	) {
    (new utils.ExcelUtils()).CellToString(
        	cell)
}

def static "utils.ExcelUtils.setCellData"(
    	String Status	
     , 	String Result	
     , 	int RowNum	
     , 	int StatusColNum	
     , 	int ResultColNum	) {
    (new utils.ExcelUtils()).setCellData(
        	Status
         , 	Result
         , 	RowNum
         , 	StatusColNum
         , 	ResultColNum)
}

def static "pac.tc.refreshBrowser"() {
    (new pac.tc()).refreshBrowser()
}

def static "pac.tc.clickElement"(
    	TestObject to	) {
    (new pac.tc()).clickElement(
        	to)
}

def static "pac.tc.test"() {
    (new pac.tc()).test()
}

def static "pac.key.locator"(
    	String attribute	
     , 	String attrval	) {
    (new pac.key()).locator(
        	attribute
         , 	attrval)
}
